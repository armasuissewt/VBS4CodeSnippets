#include "\bisim_headers\defines_base.hpp"
class bisim_turret_afv_cannon_base;
class IWA_Anims_Car;
class IWVAction_IWA;
class CfgPatches
{
	class ar_easy_car
	{
		units[]={};
		weapons[]={};
		requiredVersion=0.1;
		requiredAddons[]=
		{
			"vbs2_vehicles_Land_Wheeled"
		};
		modules[]={};
	};
};
class CfgVehicleClasses
{
	class custom_category_Car
	{
		displayname="Custom Cars";
	};
};
class CfgVehicles
{
	class bisim_car_base_x;
	class ar_easy_car_base: bisim_car_base_x
	{
	};
	class ar_easy_car: ar_easy_car_base
	{
		vehicleClass="custom_category_Car";
		
		class IWVActions
		{
			class IWVAction_IWA : IWVAction_IWA {};
		};
		
		class IWA_Anims: IWA_Anims_Car
		{
			class CameraHeightElevation // exact same name as in model.cfg
			{
				displayname="Height Adjustment";
				namephaseup="Up";
				namephasedown="Down";
				perioddown=1;
				periodup=1;
			};
		};
			
		class turrets
		{			
			class MainTurret: bisim_turret_afv_cannon_base
			{
				minElev=-90; 
				maxElev=+90; 
				initElev=0;
				minTurn=-180; 
				maxTurn=+180; 
				initTurn=0;
				
				gunnerAction="vbs2_Stryker_GunnerOut_centered";
				gunnerInAction="vbs2_Stryker_Gunner_centered";
				gunnerOutForceOptics="false";
				gunnerForceOptics="false";
				memoryPointGunnerOptics="MainTurret_Optics_pos";
				memoryPointGunnerOutOptics="MainTurret_OutOptics_pos";
				gunBeg="MainTurret_gun_dir";
				gunEnd="MainTurret_gun_pos";
				memoryPointGun="MainTurret_coax_pos";
				selectionFireAnim="MainTurret_muzzleflash";
				missileBeg="MainTurret_missile_dir";
				missileEnd="MainTurret_missile_pos";
				memoryPointMissile[]=
				{
					"MainTurret_Gun_dir",
					"MainTurret_Missile_dir"
				};
				memoryPointMissileDir[]=
				{
					"MainTurret_Gun_pos",
					"MainTurret_Missile_pos"
				};
				memoryPointsGetInGunner="MainTurret_getin_pos";
				memoryPointsGetInGunnerDir="MainTurret_getin_dir";
				body="MainTurret_trav_anim";
				gun="MainTurret_elev_anim";
				animationSourceBody="MainTurret_trav_source";
				animationSourceGun="MainTurret_elev_source";
				animationSourceHatch="MainTurret_hatch_source";
				class ViewOptics
				{
					class MainOptics
					{
						class OpticModes
						{
							class day
							{
								Type="Day";
								opticsModel="\vbs2\weapons\optics\2d\optic_T72_gunner.p3d";
								initFov="0.25/3";
								minFov="0.25/10";
								maxFov="0.25/3";
								opticsColor[]={1,1,1,1};
							};
							class night: day
							{
								Type="NV";
							};
							class ti: day
							{
								Type="TI";
								TIModes[]={2,3};
							};
						};
					};
				};
				weapons[]=
				{
				};
				magazines[]=
				{
				};
			};
		};
		class Wheels
		{
			class wheel_1_1
			{
				boneName="wheel_1_1_damper";
				center="wheel_1_1_axis";
				boundary="wheel_1_1_bound";
				steering="true";
				spring=0;
				damping=0;
			};
			class wheel_1_2: wheel_1_1
			{
				boneName="wheel_1_2_damper";
				center="wheel_1_2_axis";
				boundary="wheel_1_2_bound";
				spring=0;
				damping=0;
			};
			class wheel_2_1
			{
				boneName="wheel_2_1_damper";
				center="wheel_2_1_axis";
				boundary="wheel_2_1_bound";
				steering="false";
				spring=0;
				damping=0;
			};
			class wheel_2_2: wheel_2_1
			{
				boneName="wheel_2_2_damper";
				center="wheel_2_2_axis";
				boundary="wheel_2_2_bound";
				spring=0;
				damping=0;
			};
		};
		displayName="ar_easy_car";
		maxSpeed=100;
		enginePower=100;
		tireType=0;
		side=1;
		crew="vbs2_us_army_rifleman_ocp_m_medium_iotv_none_m4cco";
		armor=150;
		driverAction="vbs2_HMMWV_Driver";
		cargoAction[]=
		{
			"vbs2_HMMWV_Driver"
		};
		scope=2;
		hasCommander=0;
		hiddenSelections[]={};
		class Information
		{
			class MapIcons
			{
				sidc2525c="SFGPUST-----";
			};
		};
		model="armasuisse\ar_easy_car\ar_easy_car.p3d";
		transportSoldier=3;
		cargoIsCoDriver[]=
		{
			"true",
			"false"
		};
		threat[]={0.5,0,0,0};
		cost=5000;
		wheelSideFrictionCoef=1.5;
		engineBrakeCoef=0.1;
		vehicleConeIndex=35;
		terrainCoef=2.5;
		redRpm=2300;
		engineLosses=10;
		transmissionLosses=100;
		class complexGearbox
		{
			GearboxRatios[]=
			{
				"$STR_UI_GEAR_R1",
				-10,
				"$STR_UI_GEAR_N",
				0,
				"$STR_UI_GEAR_F1",
				12.2,
				"$STR_UI_GEAR_F2",
				5.7,
				"$STR_UI_GEAR_F3",
				3.4,
				"$STR_UI_GEAR_F4",
				2,
				"$STR_UI_GEAR_F5",
				1.6,
				"$STR_UI_GEAR_F6",
				1.2
			};
			gearBoxMode="manual";
			moveOffGear=1;
			driveString="$STR_UI_GEAR_D";
			neutralString="$STR_UI_GEAR_N";
			reverseString="$STR_UI_GEAR_R";
			gearUpMaxCoef=0.95;
			gearDownMaxCoef=0.85;
			gearUpMinCoef=0.65;
			gearDownMinCoef=0.55;
		};
		soundEngine[]=
		{
			"\vbs2\vehicles\Land\Wheeled\data\Sound\4WD_Loop1",
			"DB+3",
			0.8,
			400
		};
		class Sounds
		{
			class Engine
			{
				sound="soundEngine";
				type="soundEngine";
				frequency="(randomizer*0.05+0.8)*rpm*0.0005";
				volume="engineOn*(rpm factor[0.4, 0.9])";
			};
			class Movement
			{
				sound="soundEnviron";
				type="soundEnviron";
				frequency="(speed+angVelocity)*0.03334";
				volume="((speed+angVelocity)*0.03334)+(1-((speed+angVelocity)*0.03334))*0.3";
			};
		};
	};
};
