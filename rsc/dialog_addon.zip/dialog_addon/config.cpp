// config.cpp (inside your addon folder that becomes the PBO)

#include "\vbs2\headers\vbs3_config_dialogs.hpp"   // your base VBS UI classes/macros

class CfgPatches
{
    class my_addon_ui
    {
        units[] = {};
        weapons[] = {};
        requiredVersion = 0.1;
        requiredAddons[] = {};   // add dependencies here if needed
    };
};

class RscTitles
{
    #include "ui\vbs_AddonRscTextTest.hpp"  // <-- put your class vbs_AddonRscTextTest in this file
};
