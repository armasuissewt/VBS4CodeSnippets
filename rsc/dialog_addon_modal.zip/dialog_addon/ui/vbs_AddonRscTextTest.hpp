class vbs_AddonRscTextTest {
    idd = 15000;

    #define DLG_W (GUI_GRID_W * 10)
    #define DLG_H (GUI_GRID_H * 5)
    #define DLG_X (0.5 - DLG_W * 0.5)
    #define DLG_Y (0.5 - DLG_H * 0.5)
    #define TITLE_H (GUI_GRID_H)
    #define BTN_H (GUI_GRID_H)
    #define BTN_W (GUI_GRID_W * 5)

    class ControlsBackground {
        class Title : vbs3_menu_titleText {
            style = ST_LEFT;
            x     = DLG_X;
            y     = DLG_Y;
            w     = DLG_W;
            h     = TITLE_H;
            text  = "This is an ADDON Dialog";
        };

        class Background : vbs3_menu_blackBackground {
            x     = DLG_X;
            y     = DLG_Y + TITLE_H;
            w     = DLG_W;
            h     = DLG_H - TITLE_H;
        };
    };
};
